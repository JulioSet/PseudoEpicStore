/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyek.pbo;

/**
 *
 * @author User
 */
public class Transaksi {
      protected String nama;
      protected int nominal;

      public Transaksi(String nama, int nominal) {
            this.nama = nama;
            this.nominal = nominal;
      }

      public String getNama() {
            return nama;
      }

      public void setNama(String nama) {
            this.nama = nama;
      }

      public int getNominal() {
            return nominal;
      }

      public void setNominal(int nominal) {
            this.nominal = nominal;
      }
}
