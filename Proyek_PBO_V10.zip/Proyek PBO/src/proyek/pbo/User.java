/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyek.pbo;

import java.util.ArrayList;

/**
 *
 * @author M
 */
public class User {
      protected String Nama, Email,Password;
      protected int Uang = 0;
      protected ArrayList<Item> cart = new ArrayList<Item>();
      protected ArrayList<Item> wishlist = new ArrayList<Item>();

      public User(String Nama, String Email, String Password) {
          this.Nama = Nama;
          this.Email= Email;
          this.Password = Password;
      }
      public String getEmail() {
          return Email;
      }

      public void setEmail(String Email) {
          this.Email = Email;
      }

      public String getPassword() {
          return Password;
      }

      public void setPassword(String Password) {
          this.Password = Password;
      }

      public String getNama() {
          return Nama;
      }

      public void setNama(String Nama) {
          this.Nama = Nama;
      }

      public int getUang() {
          return Uang;
      }

      public void setUang(int Uang) {
          this.Uang = Uang;
      }

        public ArrayList<Item> getCart() {
              return cart;
        }

      public void setCart(ArrayList<Item> cart) {
            this.cart = cart;
      }

      public ArrayList<Item> getWishlist() {
            return wishlist;
      }

      public void setWishlist(ArrayList<Item> wishlist) {
            this.wishlist = wishlist;
      }
}
