/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyek.pbo;

import java.util.ArrayList;

/**
 *
 * @author list_user
 */
public class ProyekPBO {
    static ArrayList<User> list_user = new ArrayList<User>();
    static ArrayList<Item> list_item=new ArrayList<>();
    static ArrayList<Transaksi> list_transaksi = new ArrayList<Transaksi>();
    public static void main(String[] args) {
        LoginForm f = new LoginForm();
        f.setVisible(true);
        f.setLocationRelativeTo(null);
    }
    
}
