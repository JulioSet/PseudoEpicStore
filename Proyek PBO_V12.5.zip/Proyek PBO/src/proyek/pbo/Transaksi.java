/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyek.pbo;

/**
 *
 * @author User
 */
public class Transaksi {
      protected String nama,namabarang;
      protected int nominal;

      public Transaksi(String nama, int nominal, String namabarang) {
            this.nama = nama;
            this.nominal = nominal;
            this.namabarang=namabarang;
      }

      public String getNama() {
            return nama;
      }

      public void setNama(String nama) {
            this.nama = nama;
      }

      public int getNominal() {
            return nominal;
      }

      public void setNominal(int nominal) {
            this.nominal = nominal;
      }
       
      String Transaksi(){
          return nama+" Membeli barang "+namabarang+" Dengan harga "+nominal;
      }
}
