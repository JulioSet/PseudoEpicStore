/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyek.pbo;

/**
 *
 * @author User
 */
public class ProyekPBO {
    
    public static void main(String[] args) {
        LoginForm f = new LoginForm();
        f.setVisible(true);
        f.setLocationRelativeTo(null);
    }
    
}
