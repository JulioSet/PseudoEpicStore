/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyek.pbo;

import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author User
 */
public class Item {
      protected String icon;
      protected String nama, status = "OK", deskripsi, penjual;
      protected int harga, stok, id = -1;

      public Item(String nama, String deskripsi, int harga, int stok,String ic, String penjual) {
            this.nama = nama;
            this.deskripsi = deskripsi;
            this.harga = harga;
            this.stok = stok;
            this.icon = ic;
            this.penjual = penjual;
      }

      public String getNama() {
            return nama;
      }

      public void setNama(String nama) {
            this.nama = nama;
      }

      public String getStatus() {
            return status;
      }

      public void setStatus(String status) {
            this.status = status;
      }

      public String getDeskripsi() {
            return deskripsi;
      }

      public void setDeskripsi(String deskripsi) {
            this.deskripsi = deskripsi;
      }

      public int getHarga() {
            return harga;
      }

      public void setHarga(int harga) {
            this.harga = harga;
      }

      public int getStok() {
            return stok;
      }

      public void setStok(int stok) {
            this.stok = stok;
      }

      public String getIcon() {
            return icon;
      }

      public void setIcon(String icon) {
            this.icon = icon;
      }

      public String getPenjual() {
            return penjual;
      }

      public void setPenjual(String penjual) {
            this.penjual = penjual;
      }

      public int getId() {
            return id;
      }

      public void setId(int id) {
            this.id = id;
      }
}
