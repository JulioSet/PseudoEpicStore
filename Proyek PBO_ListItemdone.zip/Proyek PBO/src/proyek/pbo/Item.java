/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyek.pbo;

import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author User
 */
public class Item {
    protected String icon;
    protected String nama, status = "OK", deskripsi;
    protected int harga, stok;

      public Item(String nama, String deskripsi, int harga, int stok,String ic) {
            this.nama = nama;
            this.deskripsi = deskripsi;
            this.harga = harga;
            this.stok = stok;
            this.icon=ic;
      }

      public String getNama() {
            return nama;
      }

      public void setNama(String nama) {
            this.nama = nama;
      }

      public String getStatus() {
            return status;
      }

      public void setStatus(String status) {
            this.status = status;
      }

      public String getDeskripsi() {
            return deskripsi;
      }

      public void setDeskripsi(String deskripsi) {
            this.deskripsi = deskripsi;
      }

      public int getHarga() {
            return harga;
      }

      public void setHarga(int harga) {
            this.harga = harga;
      }

      public int getStok() {
            return stok;
      }

      public void setStok(int stok) {
            this.stok = stok;
      }
}
