/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyek.pbo;

/**
 *
 * @author M
 */
public class User {
    private String Nama, Email,Password;

    public User(String Nama, String Email, String Password) {
        this.Nama = Nama;
        this.Email= Email;
        this.Password = Password;
    }
    
    
    

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    
}
